package com.capgemini.swissbank.dao;

public interface QueryMapperCustomer 
{
	
	public static final String viewUser="select * from user_table where userid=? and loginpassword=?";
	//public static final String insertUser="insert into user_table(AccountID ,USERID ,LOGINPASSWORD, TYPE) values(?,?,?,?)";
	public static final String VIEWMINISTATEMENT="select  TRANSACTIONID, TRANDESCRIPTION, DATEOFTRANSACTION, TRANSACTIONTYPE, TRANAMOUNT, ACCOUNTID from TRANSCATION WHERE ACCOUNTID=? AND rownum<=10 order by DATEOFTRANSACTION";
	public static final String VIEWDETAILEDSTATEMENT="select  TRANSACTIONID, TRANDESCRIPTION, DATEOFTRANSACTION, TRANSACTIONTYPE, TRANAMOUNT, ACCOUNTID from TRANSCATION WHERE ACCOUNTID=? order by DATEOFTRANSACTION";
	public static final String CHANGEPASSWORD="UPDATE  user_table SET LOGINPASSWORD=? WHERE userid=? and loginpassword=?";
	public static final String CHANGEADDRESS="UPDATE CUSTOMER SET ADDRESS=? WHERE ACCOUNTID=?";
	public static final String CHANGEPHONENUMBER="UPDATE CUSTOMER SET phoneNumber=? WHERE ACCOUNTID=?";
	
	public static final String INSERTPAYEE="INSERT INTO PAYEE_TABLE VALUES(?,?,?)";
	public static final String VIEWALLPAYEE="SELECT * FROM PAYEE_TABLE";
	public static final String INSERTTRANSACTION="INSERT INTO TRANSACTION VALUES(transaction.NEXTVAL,?,?,?,?,?)";
	public static final String UPDATEBALANCE="UPDATE ACCOUNT_MASTER SET ACCOUNTBALANCE=? WHERE ACCOUNTID=?";
	public static final String INSERTSERVICETRACKER ="INSERT INTO SERVICE_TRACKER VALUES(serviceid_seq.NEXTVAL,?,?,?,?)";
	public static final String GETREQUISITIONID="SELECT SERVICEID FROM SERVICE_TRACKER WHERE ACCOUNTID=?";
	public static final String GETSTATUS="SELECT SERVICESTATUS FROM SERVICE_TRACKER WHERE SERVICEID=?";
	
	public static final String GETTRANSACTIONPASSWORD="SELECT TRANSACTIONPASSWORD FROM USER_TABLE WHERE AccountId=?";
	public static final String GETBALANCE="SELECT ACCOUNTBALANCE FROM ACCOUNT_MASTER WHERE ACCOUNTID=?";
}
