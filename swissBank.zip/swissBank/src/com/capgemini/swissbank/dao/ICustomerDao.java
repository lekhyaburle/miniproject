package com.capgemini.swissbank.dao;

import java.util.List;

import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;

public interface ICustomerDao {
	public UserTable validateUser(int userId,String password)throws BankException;
	public List<TransactionBean> viewMiniStatement(int accountId)throws BankException;
	public List<TransactionBean> viewDetailedStatement(int accountId)throws BankException;
	public boolean changePassword(int accountId,String oldPassword,String newPassword)throws BankException;
	public boolean changeAddress(int accountId,String address)throws BankException;
	public boolean changePhoneNumber(int accountId,String phoneNumber)throws BankException;
	
	public boolean inFundTransfer(int accountIdTo,int accountIdFrom,float transactionAmount)throws BankException;
	
	public boolean insertPayee(int accountId,int payeeAccountId,String nickName)throws BankException;
	public boolean outFundTransfer(int accountId,int payeeAccountId,String transactionPassword,float transactionAmount)throws BankException; 
	
	public int generateCheque(int accountId)throws BankException;
	public String trackStatus(int requisitionId)throws BankException;
	
	}
