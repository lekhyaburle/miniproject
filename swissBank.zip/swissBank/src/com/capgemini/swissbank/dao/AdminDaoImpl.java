package com.capgemini.swissbank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.util.DBConnection;

public class AdminDaoImpl implements IAdminDao{

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		UserTable user=new UserTable();
		int records=0;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperAdmin.INSERTACCOUNTMASTER);
			preparedStatement.setString(1,accMasterBean.getType() );
			preparedStatement.setDouble(2, accMasterBean.getAccBalance());
			preparedStatement.setDate(3, Date.valueOf(LocalDate.now()));			
			records=preparedStatement.executeUpdate();
			if(records>0){
				preparedStatement=conn.prepareStatement(IQueryMapperAdmin.GETACCOUNTID);
				ResultSet list=preparedStatement.executeQuery();
				while(list.next()){
					accMasterBean.setAccId(list.getInt(1));
				}
				preparedStatement=conn.prepareStatement(IQueryMapperAdmin.INSERTCUSTOMER);
				preparedStatement.setInt(1, accMasterBean.getAccId());
				preparedStatement.setString(2, customerBean.getCustomerName());
				preparedStatement.setString(3, customerBean.getEmail());
				preparedStatement.setString(4, customerBean.getAddress());
				preparedStatement.setString(5,customerBean.getPanNUm());
				preparedStatement.setString(6, customerBean.getPhoneNumber());
			
			}
			
		}catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			
			throw new BankException(e.getMessage());
		}
		
		
		return null;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

}
