package com.capgemini.swissbank.bean;

import java.util.Date;

public class TransactionBean {
	private int accId;
	private int transId;
	private String transDescription;
	private Date dateOfTrans;
	private String transType;
	private double transactionAmount;
	public TransactionBean() {
		super();
	}
	public TransactionBean(int accId, int transId, String transDescription,
			Date dateOfTrans, String transType, double transactionAmount) {
		super();
		this.accId = accId;
		this.transId = transId;
		this.transDescription = transDescription;
		this.dateOfTrans = dateOfTrans;
		this.transType = transType;
		this.transactionAmount = transactionAmount;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTransDescription() {
		return transDescription;
	}
	public void setTransDescription(String transDescription) {
		this.transDescription = transDescription;
	}
	public Date getDateOfTrans() {
		return dateOfTrans;
	}
	public void setDateOfTrans(Date dateOfTrans) {
		this.dateOfTrans = dateOfTrans;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	@Override
	public String toString() {
		return "UserTable [accId=" + accId + ", transId=" + transId
				+ ", transDescription=" + transDescription + ", dateOfTrans="
				+ dateOfTrans + ", transType=" + transType
				+ ", transactionAmount=" + transactionAmount + "]";
	}
	

}
