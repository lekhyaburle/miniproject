package com.capgemini.swissbank.bean;

public class UserTable {
	private int accId;
	private int userId;
	private String password;
	private String secretQue;
	private String transPassword;
	private String lockStatus;
	@Override
	public String toString() {
		return "AccMasterBean [accId=" + accId + ", userId=" + userId
				+ ", password=" + password + ", secretQue=" + secretQue
				+ ", transPassword=" + transPassword + ", lockStatus="
				+ lockStatus + "]";
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQue() {
		return secretQue;
	}
	public void setSecretQue(String secretQue) {
		this.secretQue = secretQue;
	}
	public String getTransPassword() {
		return transPassword;
	}
	public void setTransPassword(String transPassword) {
		this.transPassword = transPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}
	public UserTable(int accId, int userId, String password,
			String secretQue, String transPassword, String lockStatus) {
		super();
		this.accId = accId;
		this.userId = userId;
		this.password = password;
		this.secretQue = secretQue;
		this.transPassword = transPassword;
		this.lockStatus = lockStatus;
	}
	public UserTable() {
		super();
	}
	
}
