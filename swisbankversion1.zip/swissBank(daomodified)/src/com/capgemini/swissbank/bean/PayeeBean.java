package com.capgemini.swissbank.bean;

public class PayeeBean {
	
}
