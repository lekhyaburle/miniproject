package com.capgemini.swissbank.bean;

public enum type {
	Current, Savings;

}
