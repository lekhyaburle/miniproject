package com.capgemini.swissbank.bean;

public class AccMasterBean {
	private int accId;
	private String type;
	private double accBalance;
	private String lockStatus;
	public AccMasterBean() {
		super();
	}
	public AccMasterBean(int accId, String type, double accBalance,
			String lockStatus) {
		super();
		this.accId = accId;
		this.type = type;
		this.accBalance = accBalance;
		this.lockStatus = lockStatus;
	}
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}
	@Override
	public String toString() {
		return "AccMasterBean [accId=" + accId + ", type=" + type
				+ ", accBalance=" + accBalance + ", lockStatus=" + lockStatus
				+ "]";
	}
	
	
	

}
