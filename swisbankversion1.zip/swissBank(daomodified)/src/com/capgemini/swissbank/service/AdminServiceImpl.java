package com.capgemini.swissbank.service;

import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;

public class AdminServiceImpl implements IAdminService {
	
	IAdminService adminService= new AdminServiceImpl();

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		UserTable userTable= new UserTable();
		userTable=adminService.createUser(accMasterBean, customerBean);
		return userTable;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
		List<TransactionBean> list = adminService.getTransactions(choice);
		return list;
	}
	
	


}
