package com.capgemini.swissbank.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.service.CustomerServiceImpl;




public class Bankapp {

	public static void main(String[] args) {
		int uid;
		String password;
		UserTable validUser = null;
		boolean userCheck = false;
		char uType;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		Scanner input = new Scanner(System.in);

		System.out.println(
				"-------------------------------------------------------------------------------------------------");
		System.out.println("                                  WELCOME                    ");
		System.out.println(
				"-------------------------------------------------------------------------------------------------");

		do {
			
			System.out.println("Enter user id:");
			uid = input.nextInt();
			input.nextLine();
			
			System.out.println("Enter password:");
			password = input.nextLine();
			
			// contains valid user details ref userTable bean
			try {
				validUser = serviceCustomer.validateUser(uid, password);
			} catch (BankException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			if (validUser != null) {

				userCheck = true;

			} else {
				System.out.println("invalid credentials");
			}
		} while (userCheck = false);

		
		if (validUser.getType().equals("A")) {
			openAdminPage(validUser); // opens admin page
		} else {
			openUserPage(validUser); // opens customer page
		}
		input.close();

	}

	private static void openAdminPage(UserTable admin) {
		
	}
	
	private static void openUserPage(UserTable user) {
		int selection = 0;
		                               
		System.out.println("welcome " + user.getUserName() + " please enter your choice");
		
		Scanner input = new Scanner(System.in);
		do {
			// some cosmetics to be done here
			System.out.println("1. View Bank statement");
			System.out.println("2. Change password");
			System.out.println("3. Change address and/or phone number");
			System.out.println("4. Fund transfer");
			System.out.println("5. Issue new cheque");
			System.out.println("6. track chequebook/card  delivery status");
			System.out.println("7. exit");

			selection = input.nextInt();

			switch (selection) {
			case 1:
				System.out.println("here's your statement");
				showBankStatement(user);
				break;

			case 2:
				System.out.println("password changed");
				changePassword(user);
				break;

			case 3:
				System.out.println("address and phone number changed");
				changeDetails(user);
				break;

			case 4:
				System.out.println("fund transferred to blah");
				fundTransfer(user);
				break;

			case 5:
				System.out.println("new cheque");
				newChequeBook(user);
				break;

			case 6:
				System.out.println("your progress is 0");
				//trackStatus(user);
				break;

			case 7:
				System.out.println("Thank you have a nice day :-)");
				break;

			default:
				System.out.println("Invalid option");
				break;
			}

		} while (selection != 7);

		input.close();
	}
	
	private static void showBankStatement(UserTable user) {
		int choice = 0;
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("1. mini bank statement");
			System.out.println("2. detailed statement");

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				miniBankStatement(user);
				break;

			case 2:
				detailedBankStatement(user);
				break;

			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}
		} while (choice != 1 || choice != 2);
		sc.close();

	}
	
	private static void miniBankStatement(UserTable user) {

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		int accId = user.getAccId();

		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewMiniStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);

		}
	}
	
	private static void detailedBankStatement(UserTable user) {
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		int accId = user.getAccId();
		
		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewDetailedStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);
		}
	}

	private static void changePassword(UserTable user) {
		
		int accId = user.getAccId();
		String checkOldPwd = user.getPassword();
		String checkNewPwd;
		String oldPwd;
		String newPwd;
		boolean changeStatus = false;

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter your current password");
		oldPwd = sc.nextLine();

		// compare if he's entered his old pwd right
		// this validation should be performed in the service layer

		Out:
		if (checkOldPwd.equals(oldPwd)) {
			System.out.println("Enter your new password");
			newPwd = sc.nextLine();
			
			do {
				System.out.println("Reenter your new password");
				checkNewPwd = sc.nextLine();
				
				if(!(newPwd.equals(checkNewPwd))) {
					System.out.println("passwords don't match!!! ");
					System.out.println("please check and try again");
				}
				
			} while (!(newPwd.equals(checkNewPwd)));
			
			System.out.println("Are you sure, you made up your mind???");
			
			String answer=sc.nextLine();
			
			if(answer.equals("Y")||answer.equals("y"))
			{	
				try {
					changeStatus = serviceCustomer.changePassword(accId, oldPwd, newPwd);
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				if (changeStatus) {
					System.out.println("Password successfully changed");

				} else {
					System.out.println("Unable to change password");

				}
			}else
				break Out;

		} else {
			System.out.println("unable to proceed further as wrong password is entered");
		}
	}

	private static void changeDetails(UserTable user) {
		int choice = 0;
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("1. change address");
			System.out.println("2. change phone number");

			choice = sc.nextInt();

			switch (choice) {
			case 1:
				changeAddress(user);
				break;

			case 2:
				changePhoneNumber(user);
				break;

			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}
		} while (choice != 1 || choice != 2);
		sc.close();		
	}

	private static void changeAddress(UserTable user) {
		int accId = user.getAccId();
		String newAddress;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter your new address");
		newAddress = sc.nextLine();
		
		try {
			isChanged = serviceCustomer.changeAddress(accId, newAddress);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New address updated successfully");
		}else {
			System.out.println("could not update the address");
		}
		
		sc.close();
	}

	private static void changePhoneNumber(UserTable user) {
		int accId = user.getAccId();
		String newPhoneNumber;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("please enter your new Phone number");
		newPhoneNumber = sc.nextLine();
		
		try {
			isChanged = serviceCustomer.changePhoneNumber(accId, newPhoneNumber);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New phone number updated successfully");
		}else {
			System.out.println("could not update the phone number");
		}
		
		sc.close();		
	}

	private static void fundTransfer(UserTable user) {
		// don't know how to proceed
		// view all payee method does not exist in dao
	}
	
	private static void newChequeBook(UserTable user) {
		
	}
}
