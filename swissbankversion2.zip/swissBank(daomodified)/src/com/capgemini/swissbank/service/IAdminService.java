package com.capgemini.swissbank.service;

import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;

public interface IAdminService {
	public UserTable createUser(AccMasterBean accMasterBean,CustomerBean customerBean)throws BankException;
	public List<TransactionBean> getTransactions(int choice)throws BankException;
	public List<TransactionBean> getTransactionsDaily()throws BankException;
	public List<TransactionBean> getTransactionsWeekly()throws BankException;
	public List<TransactionBean> getTransactionsMonthly() throws BankException;
}
