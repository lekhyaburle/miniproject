package com.capgemini.swissbank.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.service.CustomerServiceImpl;




public class Bankapp {
	public static Scanner in=new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int uid;
		String password;
		UserTable validUser = null;
		boolean userCheck = false;
		boolean isOpen=false;
		char uType;
		int count=0;
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		//Scanner input = new Scanner(System.in);

		System.out.println(
				"-------------------------------------------------------------------------------------------------");
		System.out.println("                                  WELCOME                    ");
		System.out.println(
				"-------------------------------------------------------------------------------------------------");

		do {
			
			System.out.println("Enter user id:");
			uid = in.nextInt();
			in.nextLine();
			
			System.out.println("Enter password:");
			password = in.nextLine();
			
			// contains valid user details ref userTable bean
			try {
				validUser = serviceCustomer.validateUser(uid, password);
				 
				
			} catch (BankException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			if (validUser != null) {
				isOpen=serviceCustomer.getUserStatus(validUser);
				if(!isOpen){
					System.out.println("Sorry Your account is locked.\nContact Admin");
					userCheck=false;
				}
				userCheck = true;

			} else {
				count++;
				System.out.println("invalid credentials");
				if(count==3){
					try {
						serviceCustomer.updateLockStatus(uid);
					} catch (BankException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		} while (userCheck == false);

		
		if (validUser.getType().equals("A")) {
			openAdminPage(validUser); // opens admin page
		} else {
			openUserPage(validUser); // opens customer page
		}
		//input.close();

	}

	private static void openAdminPage(UserTable admin) {
		
	}
	
	private static void openUserPage(UserTable user) {
		int selection = 0;
		                               
		System.out.println("welcome " + user.getUserName() + " please enter your choice");
		
		//Scanner input1 = new Scanner(System.in);
		do {
			// some cosmetics to be done here
			System.out.println("1. View Bank statement");
			System.out.println("2. Change password");
			System.out.println("3. Change address and/or phone number");
			System.out.println("4. Fund transfer");
			System.out.println("5. Issue new cheque");
			System.out.println("6. track chequebook/card  delivery status");
			System.out.println("7. exit");

			selection = in.nextInt();
			in.nextLine();
			switch (selection) {
			case 1:
				System.out.println("here's your statement");
				showBankStatement(user);
				break;

			case 2:
				System.out.println("password changed");
				changePassword(user);
				break;

			case 3:
				System.out.println("address and phone number changed");
				changeDetails(user);
				break;

			case 4:
				System.out.println("fund transferred to blah");
				fundTransfer(user);
				break;

			case 5:
				System.out.println("new cheque");
				newChequeBook(user);
				break;

			case 6:
				
				trackStatus(user);
				break;

			case 7:
				System.out.println("Thank you have a nice day :-)");
				break;

			default:
				System.out.println("Invalid option");
				break;
			}

		} while (selection != 7);

		//input1.close();
	}
	
	

	private static void showBankStatement(UserTable user) {
		int choice = 0;
		//Scanner sc = new Scanner(System.in);

		do {
			System.out.println("1. mini bank statement");
			System.out.println("2. detailed statement");

			choice = in.nextInt();

			switch (choice) {
			case 1:
				miniBankStatement(user);
				break;

			case 2:
				detailedBankStatement(user);
				break;

			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}
		} while (choice != 1 && choice != 2);
		//sc.close();

	}
	
	private static void miniBankStatement(UserTable user) {

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		int accId = user.getAccId();

		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewMiniStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);

		}
	}
	
	private static void detailedBankStatement(UserTable user) {
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		int accId = user.getAccId();
		
		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewDetailedStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);
		}
	}

	private static void changePassword(UserTable user) {
		
		int accId = user.getAccId();
		String checkOldPwd = user.getPassword();
		String checkNewPwd;
		String oldPwd;
		String newPwd;
		boolean changeStatus = false;

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		//Scanner sc1 = new Scanner(System.in);

		System.out.println("Enter your current password");
		oldPwd = in.nextLine();

		// compare if he's entered his old pwd right
		// this validation should be performed in the service layer

		Out:
		if (checkOldPwd.equals(oldPwd)) {
			System.out.println("Enter your new password");
			newPwd = in.nextLine();
			
			do {
				System.out.println("Reenter your new password");
				checkNewPwd = in.nextLine();
				
				if(!(newPwd.equals(checkNewPwd))) {
					System.out.println("passwords don't match!!! ");
					System.out.println("please check and try again");
				}
				
			} while (!(newPwd.equals(checkNewPwd)));
			
			System.out.println("Are you sure, you made up your mind???");
			
			String answer=in.nextLine();
			
			if(answer.equals("Y")||answer.equals("y"))
			{	
				try {
					changeStatus = serviceCustomer.changePassword(accId, oldPwd, newPwd);
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				if (changeStatus) {
					System.out.println("Password successfully changed");

				} else {
					System.out.println("Unable to change password");

				}
			}else
				break Out;

		} else {
			System.out.println("unable to proceed further as wrong password is entered");
		}
		//sc1.close();
	}

	private static void changeDetails(UserTable user) {
		int choice = 0;
		//Scanner sc2 = new Scanner(System.in);

		do {
			System.out.println("1. change address");
			System.out.println("2. change phone number");

			choice = in.nextInt();
			in.nextLine();
			switch (choice) {
			case 1:
				changeAddress(user);	

				break;

			case 2:
				changePhoneNumber(user);				
				break;
				
			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}

		}			
		while (choice != 1 && choice != 2);
		
		//sc2.close();
	}
	
	private static void changeAddress(UserTable user) {
		int accId = user.getAccId();
		String newAddress;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		
		//Scanner sc = new Scanner(System.in);
		System.out.println("please enter your new address");
		newAddress = in.nextLine();
		
		try {
			isChanged = serviceCustomer.changeAddress(accId, newAddress);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New address updated successfully");
		}else {
			System.out.println("could not update the address");
		}
		
		//sc.close();
	}

	private static void changePhoneNumber(UserTable user) {
		int accId = user.getAccId();
		String newPhoneNumber;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		//Scanner sc = new Scanner(System.in);
		
		System.out.println("please enter your new Phone number");
		newPhoneNumber = in.nextLine();
		
		try {
			isChanged = serviceCustomer.changePhoneNumber(accId, newPhoneNumber);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New phone number updated successfully");
		}else {
			System.out.println("could not update the phone number");
		}
		
		//sc.close();		
	}

	private static void fundTransfer(UserTable user) {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("1.With in the same Bank");
		System.out.println("2.External Banks");
		int choice=in.nextInt();
		in.nextLine();
		switch (choice) {
		case 1:
			inFundTransfer(user);
			break;
		case 2:
			System.out.println("1.Add Payee");
			System.out.println("2.Select Payee");
			int key=in.nextInt();
			in.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter Payee Account Id:");
				int payeeAccountId=in.nextInt();
				in.nextLine();
				System.out.println("Enter Payee Nickname:");
				String nickName=in.nextLine();
				try {
					boolean isInserted=serviceCustomer.insertPayee(user.getAccId(), payeeAccountId, nickName);
					if(isInserted)
						System.out.println("Payee added successfully.");
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				
				System.out.println("The list of payees registered are:");
				try {
					List<PayeeBean> payeeList=serviceCustomer.viewPayee(user.getAccId());
					
					for (PayeeBean payeeBean : payeeList) {
						System.out.println(payeeBean);
					}
					
					System.out.println("Enter Transaction password");
					String transactionPassword=in.nextLine();
					if(serviceCustomer.validateTransactionPassword(transactionPassword, user))
					{
						System.out.println("Enter payee AccountID");
						int payeeAccountNumber=in.nextInt();
						in.nextLine();
					System.out.println("Enter amount");
					double transactionAmount=in.nextDouble();
					in.nextLine();
					if(serviceCustomer.validateTransactionAmount(transactionAmount)){
					double balance=serviceCustomer.outFundTransfer(user.getAccId(), payeeAccountNumber, transactionPassword, transactionAmount);
					System.out.println("Transaction successful\nyour current balance is "+balance);
					}
					else{
						System.out.println("Can not transact more than 1000000");
					}
					}
					else{
						System.out.println("Invalid Transaction password");
					}
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			default:
				break;
			}
			
			
			break;
		default:
			break;
		}
		
		
	}
	
	private static void newChequeBook(UserTable user)  {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		try {
			int requisitionId=serviceCustomer.generateCheque(user.getAccId());
			System.out.println("Your requisition id is"+requisitionId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void trackStatus(UserTable user) {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("Enter the requisition Id");
		int requisitionId=in.nextInt();
		in.nextLine();
		try {
			String status=serviceCustomer.trackStatus(requisitionId);
			System.out.println("Your status is "+status);
		} catch (BankException e) {
			
			e.printStackTrace();
		}
		
	}
	
	private static void inFundTransfer(UserTable user){
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("Enter payee Account Id");
		int accountIdTo=in.nextInt();
		in.nextLine();
		System.out.println("Enter Transaction amount");
		double transactionAmount=in.nextDouble();			
		in.nextLine();
		try {
			double balance=serviceCustomer.inFundTransfer(accountIdTo, user.getAccId(), transactionAmount);
			System.out.println("Transaction is successful\nYour Balance is "+balance);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
