package com.capgemini.swissbank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.util.DBConnection;

public class AdminDaoImpl implements IAdminDao {

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		UserTable user=new UserTable();
		int records=0;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperAdmin.INSERTACCOUNTMASTER);
			preparedStatement.setString(1,accMasterBean.getType().toString() );
			preparedStatement.setDouble(2, accMasterBean.getAccBalance());
			preparedStatement.setDate(3, Date.valueOf(LocalDate.now()));			
			records=preparedStatement.executeUpdate();
			if(records>0){
				preparedStatement=conn.prepareStatement(IQueryMapperAdmin.GETACCOUNTID);
				ResultSet list=preparedStatement.executeQuery();
				while(list.next()){
					accMasterBean.setAccId(list.getInt(1));
				}
				preparedStatement=conn.prepareStatement(IQueryMapperAdmin.INSERTCUSTOMER);
				preparedStatement.setInt(1, accMasterBean.getAccId());
				preparedStatement.setString(2, customerBean.getCustomerName());
				preparedStatement.setString(3, customerBean.getEmail());
				preparedStatement.setString(4, customerBean.getAddress());
				preparedStatement.setString(5,customerBean.getPanNUm());
				preparedStatement.setString(6, customerBean.getPhoneNumber());
				records=preparedStatement.executeUpdate();
				if(records>0){
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.INSERTUSER);
					preparedStatement.setInt(1, accMasterBean.getAccId());
					preparedStatement.setString(2, "qwerty");
					preparedStatement.setString(3,"C");
					preparedStatement.setString(4,"o");
					records=preparedStatement.executeUpdate();
					if(records>0){
						user.setAccId(accMasterBean.getAccId());
						user.setPassword("qwerty");
						user.setType("C");
						preparedStatement=conn.prepareStatement(IQueryMapperAdmin.GETUSERID);
						 list=preparedStatement.executeQuery();
						while(list.next()){
									user.setUserId(list.getInt(1));
						}
						
					}
				}
			
			}
			
		}catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			
			throw new BankException(e.getMessage());
		}
		
		
		return user;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
	
		
			int transactionNumber=0;
			List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
			try{Connection conn=DBConnection.getInstance().getConnection();
			
			ResultSet rs=null;
			PreparedStatement preparedStatement=null;
					
			
				if(choice==1)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONDAILY);
				else if(choice==2)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONWEEKLY);	
				else if(choice==3)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONMONTHLY);
				else
					return null;
				rs=preparedStatement.executeQuery();
				
				while(rs.next())
				{
					TransactionBean bean=new TransactionBean();
					bean.setAccId(rs.getInt(1));
					bean.setDateOfTrans(rs.getDate(2));
					bean.setTransDescription(rs.getString(3));
					bean.setTransId(rs.getInt(4));
					bean.setTransType(rs.getString(5));
					bean.setTransactionAmount(rs.getDouble(6));
					
					transactionList.add(bean);
					transactionNumber++;
				
				}
			} catch(SQLException sqlEx)
			{
				throw new BankException(sqlEx.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new BankException(e.getMessage());
			}	
			if(transactionNumber == 0)
				return null;
			else
				return transactionList;
			
		}
		
	}


