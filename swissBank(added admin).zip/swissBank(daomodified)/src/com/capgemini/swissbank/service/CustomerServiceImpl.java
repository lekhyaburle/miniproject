package com.capgemini.swissbank.service;

import java.util.List;

import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.dao.CustomerDaoImpl;
import com.capgemini.swissbank.dao.ICustomerDao;
import com.capgemini.swissbank.exception.BankException;

public class CustomerServiceImpl implements ICustomerDao {
	
	
	ICustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public UserTable validateUser(int userId, String password)
			throws BankException {
		
		UserTable userTable= new UserTable();
		userTable=customerDao.validateUser(userId, password);
		return userTable;
	}

	@Override
	public List<TransactionBean> viewMiniStatement(int accountId)
			throws BankException {
		List<TransactionBean> list = customerDao.viewMiniStatement(accountId);
		return list;
	}

	@Override
	public List<TransactionBean> viewDetailedStatement(int accountId)
			throws BankException {
		List<TransactionBean> list= customerDao.viewDetailedStatement(accountId);
		return list;
	}

	@Override
	public boolean changePassword(int accountId, String oldPassword,
			String newPassword) throws BankException {
		
		return customerDao.changePassword(accountId, oldPassword, newPassword);
	}

	@Override
	public boolean changeAddress(int accountId, String address)
			throws BankException {
		
		return customerDao.changeAddress(accountId, address);
	}

	@Override
	public boolean changePhoneNumber(int accountId, String phoneNumber)
			throws BankException {
		
		return customerDao.changePhoneNumber(accountId, phoneNumber);
	}

	@Override
	public double inFundTransfer(int accountIdTo, int accountIdFrom,
			double transactionAmount) throws BankException {
		
	
		return customerDao.inFundTransfer(accountIdTo, accountIdFrom, transactionAmount);
	}

	@Override
	public boolean insertPayee(int accountId, int payeeAccountId,
			String nickName) throws BankException {
		
		return customerDao.insertPayee(accountId, payeeAccountId, nickName);
	}

	@Override
	public double outFundTransfer(int accountId, int payeeAccountId,
			String transactionPassword, double transactionAmount)
			throws BankException {
		return customerDao.outFundTransfer(accountId, payeeAccountId, transactionPassword, transactionAmount);
	}

	@Override
	public int generateCheque(int accountId) throws BankException {
		
		return customerDao.generateCheque(accountId);
	}

	@Override
	public String trackStatus(int requisitionId) throws BankException {
		
		return customerDao.trackStatus(requisitionId);
	}
	
	
	public boolean getUserStatus(UserTable validUser)
	{
		if(validUser.getLockStatus().equals("o"))
			return true;
		else
			return false;
		
	}

	@Override
	public List<PayeeBean> viewPayee(int accountId) throws BankException {
		
		return customerDao.viewPayee(accountId);
	}
	public boolean validateTransactionPassword(String transactionPassword,UserTable user){
		if(transactionPassword.equals(user.getTransPassword()))
			return true;
		else return false;
	}

	public boolean validateTransactionAmount(double transactionAmount){
		if(transactionAmount<1000000)
			return true;
		else return false;
	}

	@Override
	public boolean updateLockStatus(int accountId) throws BankException {
		
		return customerDao.updateLockStatus(accountId);
	}
	
	
}
