package com.capgemini.swissbank.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.dao.AdminDaoImpl;
import com.capgemini.swissbank.dao.IAdminDao;
import com.capgemini.swissbank.exception.BankException;

public class AdminServiceImpl implements IAdminService {
	
	IAdminDao adminDao= new AdminDaoImpl();

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		UserTable userTable= new UserTable();
		userTable=adminDao.createUser(accMasterBean, customerBean);
		return userTable;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
		List<TransactionBean> list = adminDao.getTransactions(choice);
		return list;
	}

	@Override
	public List<TransactionBean> getTransactionsDaily() throws BankException {
		
		return adminDao.getTransactions(1);
	}

	@Override
	public List<TransactionBean> getTransactionsWeekly() throws BankException {
		// TODO Auto-generated method stub
		return adminDao.getTransactions(2);
	}

	@Override
	public List<TransactionBean> getTransactionsMonthly() throws BankException {
		// TODO Auto-generated method stub
		return adminDao.getTransactions(3);
	}
	
	public List<String> isValidNewCustomer(CustomerBean customerBean,AccMasterBean accMasterBean) {
		List<String> errorList = new ArrayList<String>();

		Pattern pattern = null;
		Matcher matcher = null;

		

		// Phone Number Validation
		pattern = Pattern.compile("^[7-9]{1}[0-9]{9}");
		matcher = pattern.matcher(customerBean.getPhoneNumber());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Phone Number");
		}

		// Address Validation
		pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
		matcher = pattern.matcher(customerBean.getAddress());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Address");
		}
		
		//e-mail Validation
		pattern = Pattern.compile("\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
		matcher = pattern.matcher(customerBean.getEmail());

		if (!matcher.matches()) {
			errorList.add("Please enter a valid Email Id");
		}
		// Amount Validation
		if (accMasterBean.getAccBalance()<3000) {
			errorList.add("Minimum balance should be 3000");
		}
		
		 
		
		return errorList;
	}
	


}
